<?php
include 'ban.php';
include 'index1.php'; 
?>